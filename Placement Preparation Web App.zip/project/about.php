<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>

<body>


    <section>
        <?php include 'nav_bar.php';?>
    </section>

    <!-- header -->



    <!-- Start content -->
    <form class="about-form">
        <h2 style="color:#0189d2;">About Us</h2>
        <p>Welcome to Brain Sprint, your go-to platform for comprehensive placement preparation. Our mission is to empower students and professionals with the skills and confidence needed to excel in exams and job interviews. We offer a balanced approach, combining rigorous practice modules in quantitative aptitude, verbal ability, logical reasoning, and coding, with wellness resources like guided meditation videos to relieve stress and enhance concentration. <br>Join Brain Sprint and embark on your journey to success with our supportive and enriching community.
        </p>
        <p>Our Team comprises of :-</p>
        <p>AADHYA A (Leader), C DISHA(Member), BHARGAV BS (Member)
</p>
    </form>
    <!-- end content -->




    <!-- footer -->

    <section>
        <?php include 'footer/footer.php';?>
    </section>
</body>

</html>