<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Read For Speed Sitemap</title>
    <link rel="stylesheet" href="./css/style.css">
    
</head>
<body>
<section>

<?php include 'nav_bar.php';?>
<h2 class="heading-arch" align='center'> Architecture Of Read For Speed </h2>
<div class="site">
<img src="./images/Sitemap2.jpg" alt="sitemap">
</div>
<style>
  .site img{
    height: 100%; width: 100%;
  }
</style>
</section>
</div>
</body>
</html>