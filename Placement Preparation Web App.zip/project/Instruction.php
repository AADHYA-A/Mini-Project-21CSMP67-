<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <title>Instruction</title>
    <link rel="stylesheet" href="css/styles4.css">
    <link rel="shortcut icon" type="images/png" href="images/f.png"/>
</head>

<body>
<section>

<?php include 'nav_bar.php';?>

</section>

    <div class="container">
        <header>
            <h1>
                Instructions
            </h1>
        </header>
        <figure>
            <image src="https://static1.s123-cdn-static-a.com/uploads/2587645/800_5db1acde16bec.jpg">
        </figure>
        <main id="main-doc">
            
            <section>
                <p>
                Welcome to Brain Sprint, your go-to platform for comprehensive placement preparation. Our mission is to empower students and professionals with the skills and confidence needed to excel in exams and job interviews. Here’s how to make the most of our platform:<br>
                </p><br>
                <p>
                    <span>Practice Sessions</span><br>
                    Each practice session is designed to provide focused and efficient preparation. You will have 30 minutes to solve 15 questions in each section:
                </p>
                    <p>* Quantitative Aptitude</p>
                    <p>* Verbal Ability</p>
                    <p>* Logical Reasoning</p>
                    <p>* Coding</p>

            </section><br>
            <span>How to Use Brain Sprint</span><br>
            <section>
                <h4>1.Select a Section:</h4>
                <p>
                Choose the area you want to practice—Quantitative Aptitude, Verbal Ability, Logical Reasoning, or Coding.
                </p>
            </section><br>
            <section>
                <h4>2.Start a Session:</h4>
                <p>
                Each session has a 30-minute time limit, featuring 20 questions for Quantitative Aptitude and 10 questions each for Verbal Ability, Logical Reasoning, and Coding. This structure helps you manage your time effectively. All sections are separate, allowing you to focus on one area at a time.
                </p>
            </section><br>
            <section>
                <h4>3.Submit Answers:</h4>
                <p>
                Once you complete the questions, submit your answers to get instant feedback and detailed explanations. If your score is less than 60%, you will be provided with a link to the study material to improve your score.
                </p>
            </section><br>
            <section>
                <h4>4.Review and Improve:</h4>
                <p>
                Analyze your performance, identify areas for improvement, and focus on those in your next practice sessions.
                </p>
            </section><br>
                  
                <p>
                    <span>Wellness Resources</span>
                </p>
                <p>We believe in a balanced approach to preparation. Use our guided meditation videos to relieve stress and enhance concentration. Taking care of your mental well-being is key to effective learning.</p>
                
                  
            </section><br>
            <section>
                <p>
                <span>Join Our Community</span>
                Engage with our supportive and enriching community. Share your experiences, ask questions, and learn from others to enhance your preparation journey.</p><br>
                <p>Follow these instructions to maximize your use of Brain Sprint and take a confident step towards achieving your career goals. Happy practicing!
                </p>
              
            </section>
        </main>
        </main>
    </div>
</body>

</html>