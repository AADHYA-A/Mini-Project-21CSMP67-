<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .video-outer-container {
            width: 80%;
            max-width: 800px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
            text-align: center;
        }
        .video-container {
            position: relative;
            width: 100%;
            padding-top: 56.25%; /* 16:9 Aspect Ratio (divide 9 by 16 = 0.5625) */
        }
        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
    </style>
</head>

<body>


    <section>
        <?php include 'nav_bar.php';?>
    </section>

    <!-- header -->



    <!-- Start content -->
    <div class="video-outer-container">
        <h1>Guided Meditation Videos</h1>
        <br><br>
        <div class="video-container">
            <!-- Replace 'DulNz2CkoHI' with the actual video ID if different -->
            <iframe width="560" height="315" src="https://www.youtube.com/embed/QpNmkpbxryM" frameborder="0" allowfullscreen></iframe>
        </div>
        
        
                <br><br><br><br>
        <div class="video-container">
            <!-- Replace 'DulNz2CkoHI' with the actual video ID if different -->
            <iframe width="560" height="315" src="https://www.youtube.com/embed/vj0JDwQLof4" frameborder="0" allowfullscreen></iframe>
                </div>
      
    </div>
    </div>
    <!-- end content -->




    <!-- footer -->

    <section>
        <?php include 'footer/footer.php';?>
    </section>
</body>

</html>