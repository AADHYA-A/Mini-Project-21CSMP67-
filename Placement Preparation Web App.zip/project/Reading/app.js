// function funClick(arg){

//   // var count = arg.length;
//   alert(arg)

// }