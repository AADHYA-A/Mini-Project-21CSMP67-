<?php 


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ReadforSpeed-Login page</title>
</head>
<body>



            
 
<header class="wrapper">

 
<h1 class="logo"><a href="../index.php"> 
    <img src="../images/logo.png"  alt="img" width="300px" height="300px"> </a> </h1>


</header>
<section class="sctn">
<form action="welcome.php" method="get">
      <div class="heading">
          <h2>Log In</h2>
          <hr>
          </div>
    <div class="text-field">
        <label>Email</label>
        <input type="text" name="email" >
      
    </div>
    <div class="text-field">
        <label>Password</label>
        <input type="password">
       
    </div>
    
       <div class="term"> 
        <input type="checkbox" class="chbox">
        <label>Remember Me</label>

    </div>
    </div>
        <button type="button" class="btn-card-head2">Submit</button>

            
        </div>

        <div class="haveac">
            Don't Have a account? <a href="Signup.php">Sign Up</a>
            <p> By clicking the submit button you accept our term and Condition</p>
        </div>

    </form>
</section>
        


    
</body>
</html>