# Smart-India-Hackthon-2022
This is the project of Smart India Hackathon 2022 that problem statement assigned by DRDO
