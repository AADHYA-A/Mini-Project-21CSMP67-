<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            text-align: center;
            margin-top: 50px;
        }
        h1 {
            color: #333;
        }
        .options {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        .option {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            margin: 10px;
            text-decoration: none;
            border-radius: 10px;
            transition: background-color 0.3s;
        }
        .option:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <br><h1>Welcome to the Exercise Menu. Please select one of the following options:</h1><br>
        <div class="options">
            <a href="quantitude.php" class="option">Quantitative Aptitude</a>
            <a href="verbal.php" class="option">Verbal Ability</a>
            <a href="logical.php" class="option">Logical Reasoning</a>
            <a href="coding.php" class="option">Programming</a>
        </div>
    </div><br><br><br><br>
        <section align="center">

                    <img src=https://institute.careerguide.com/wp-content/uploads/2020/10/3f7d8dedfca501015a14b977312b3df0.gif>


                    </section>
</body>
</html>
