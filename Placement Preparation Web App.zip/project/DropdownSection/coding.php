
<?php
session_start();

// Define the questions and options
$questions = [
    1 => [
        "question" => "What is the output of the following C++ code snippet?<br><br>#include <iostream><br>using namespace std;<br>int main() {<br>    int x = 5;<br>    cout << ++x + x++;<br>    return 0;<br>}",
        "options" => [
            "A. 11",
            "B. 12",
            "C. 13",
            "D. 14"
        ],
        "answer" => "C"
    ],
    2 => [
        "question" => "Which of the following correctly declares a pure virtual function in C++?",
        "options" => [
            "A. virtual void function() = 0;",
            "B. void virtual function() = 0;",
            "C. void virtual function();",
            "D. void function() = 0;"
        ],
        "answer" => "A"
    ],
    3 => [
        "question" => "In C++, what is the correct way to initialize a member variable 'count' of class 'Counter' using an initializer list?",
        "options" => [
            "A. Counter::Counter() { count = 0; }",
            "B. Counter::Counter() : count(0) {}",
            "C. Counter::Counter(int c) { count = c; }",
            "D. Counter::Counter() : this->count(0) {}"
        ],
        "answer" => "B"
    ],
    4 => [
        "question" => "What does the 'friend' keyword signify in C++?",
        "options" => [
            "A. It declares a private member function.",
            "B. It allows a function or class to access private members of another class.",
            "C. It indicates a static method.",
            "D. It specifies a virtual function."
        ],
        "answer" => "B"
    ],
    5 => [
        "question" => "Which of the following is not a valid access specifier in C++?",
        "options" => [
            "A. public",
            "B. private",
            "C. protected",
            "D. internal"
        ],
        "answer" => "D"
    ],
    6 => [
        "question" => "What is the output of the following C++ code?<br><br>#include <<iostream>> <br>using namespace std;<br><br>class Base {<br>public:<br>    virtual void display() <br>{ <br>cout << \"Base\"; }<br>};<br><br>class Derived : <br>public Base <br>{<br>public:<br>    void display() <br> override { <br> cout << \"Derived\"; <br> }<br>};<br><br>int main() {<br>    Base* ptr = new Derived();<br>    ptr->display();<br>    delete ptr;<br>    return 0;<br>}",
        "options" => [
            "A. Base",
            "B. Derived",
            "C. Compilation error",
            "D. Runtime error"
        ],
        "answer" => "B"
    ],
    7 => [
        "question" => "What is the concept in C++ that allows a class to inherit properties and behavior from another class?",
        "options" => [
            "A. Polymorphism",
            "B. Inheritance",
            "C. Encapsulation",
            "D. Abstraction"
        ],
        "answer" => "B"
    ],
    8 => [
        "question" => "Which keyword is used to prevent further inheritance of a class in C++?",
        "options" => [
            "A. sealed",
            "B. final",
            "C. end",
            "D. stop"
        ],
        "answer" => "B"
    ],
    9 => [
        "question" => "What is the output of the following C++ code?<br><br>#include <iostream><br>using namespace std;<br>class Base {<br>public:<br>    void show()<br> { cout << \"Base\"; <br>}<br>};<br><br>class Derived : public Base {<br>public:<br>    void show() <br>{ <br>cout << \"Derived\"; <br>}<br>};<br>int main() {<br>    Derived d;<br>    Base* ptr = &d;<br>    ptr->show();<br>    return 0;<br>}",
        "options" => [
            "A. Base",
            "B. Derived",
            "C. Compilation error",
            "D. Runtime error"
        ],
        "answer" => "A"
    ],
    10 => [
        "question" => "What is the default access specifier for members of a class in C++?",
        "options" => [
            "A. private",
            "B. protected",
            "C. public",
            "D. internal"
        ],
        "answer" => "A"
    ]
];


$current_question = isset($_SESSION['current_question']) ? $_SESSION['current_question'] : 1;
$score = isset($_SESSION['score']) ? $_SESSION['score'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_option = $_POST['option'];
    if ($selected_option == $questions[$current_question]['answer']) {
        $score++;
        $_SESSION['score'] = $score;
    }
    $current_question++;
    $_SESSION['current_question'] = $current_question;
}

// Set the time limit in seconds (30 minutes = 30 * 60 seconds)
$time_limit = 30 * 60;
$end_time = isset($_SESSION['quiz_end_time']) ? $_SESSION['quiz_end_time'] : time() + $time_limit;
$_SESSION['quiz_end_time'] = $end_time;

// Calculate time left
$time_left = $end_time - time();
if ($time_left < 0) {
    $time_left = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quantitude Exercise</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 10px 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            display: block;
            margin: 20px 0;
            padding: 10px 15px;
            background-color: #5cb85c;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .score {
            font-size: 20px;
            color: #333;
        }
        #timer {
            font-size: 20px;
            margin-bottom: 20px;
            color: #ff0000;
        }
        .btn-container {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #0056b3;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .btn:hover {
            background-color: #004499;
        }
    </style>
    <script>
        // JavaScript countdown timer
        var timerInterval = setInterval(function() {
            var now = <?php echo time(); ?>;
            var endTime = <?php echo $_SESSION['quiz_end_time']; ?>;
            var timeLeft = endTime - now;

            var minutes = Math.floor(timeLeft / 60);
            var seconds = timeLeft % 60;

            document.getElementById('timer').textContent = 'Time left: ' + minutes + 'm ' + seconds + 's';

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timer').textContent = 'Time is up!';
                document.getElementById('quizForm').submit(); // Automatically submit the quiz when time is up
            }
        }, 1000);
    </script>
</head>
<body>
    <div class="container">
        <?php
        if ($current_question > count($questions)) {
            echo "<h1>Quiz Completed!</h1>";
            echo "<p>Your final score is: $score</p>";
            if ($score < 6){
                echo "<h5> To improve your score please refer to this study material: <a href='https://www.indiabix.com/cpp-programming/questions-and-answers/'>Click me</a></h5>  ";
                }
            
            echo "<div class='btn-container'>";
            echo "<a class='btn' href='coding.php'>Retry</a>";
            echo "<a class='btn' href='/project/DropdownSection/index.php'>Go Back</a>";
            echo "</div>";
            session_destroy();
        } else {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                echo "<p class='score'>Your current score is: $score</p>";
            }
            $question = $questions[$current_question]['question'];
            $options = $questions[$current_question]['options'];
            echo "<h1>Question $current_question</h1>";
            echo "<p>$question</p>";
            echo "<form id='quizForm' method='POST'>";
            foreach ($options as $option) {
                echo "<p><input type='radio' name='option' value='" . substr($option, 0, 1) . "' required> $option</p>";
            }
            echo "<input type='submit' value='Submit'>";
            echo "</form>";
        }
        ?>
        <div id="timer"></div>
    </div>
</body>
</html>
