<?php
session_start();

// Define the questions and options
$questions = [
    1 => [
        "question" => "Complete the sentence: She was ______ by the news of her promotion.",
        "options" => ["A. disinterested", "B. uninterested", "C. indifferent", "D. interested"],
        "answer" => "D"
    ],
    2 => [
        "question" => "Choose the correct synonym for 'ubiquitous':",
        "options" => ["A. rare", "B. omnipresent", "C. limited", "D. scarce"],
        "answer" => "B"
    ],
    3 => [
        "question" => "The team's performance was _______ to the coach's expectations.",
        "options" => ["A. up", "B. at", "C. down", "D. below"],
        "answer" => "C"
    ],
    4 => [
        "question" => "He showed _______ patience during the difficult times.",
        "options" => ["A. abundant", "B. sufficient", "C. inadequate", "D. ample"],
        "answer" => "A"
    ],
    5 => [
        "question" => "The new policy aims to _______ costs and increase efficiency.",
        "options" => ["A. cut down", "B. break down", "C. put down", "D. get down"],
        "answer" => "A"
    ],
    6 => [
        "question" => "Choose the correct word to complete the analogy: Book is to reading as fork is to _______.",
        "options" => ["A. eating", "B. writing", "C. cooking", "D. stirring"],
        "answer" => "A"
    ],
    7 => [
        "question" => "The company decided to _______ its efforts towards sustainable practices.",
        "options" => ["A. turn up", "B. turn on", "C. turn off", "D. turn down"],
        "answer" => "D"
    ],
    8 => [
        "question" => "She felt _______ after hearing the heartfelt apology.",
        "options" => ["A. secure", "B. relieved", "C. anxious", "D. worried"],
        "answer" => "B"
    ],
    9 => [
        "question" => "Choose the appropriate idiom: 'To beat around the bush' means _______.",
        "options" => ["A. to be direct", "B. to avoid the main topic", "C. to discuss openly", "D. to confront"],
        "answer" => "B"
    ],
    10 => [
        "question" => "His speech was filled with _______ that captivated the audience.",
        "options" => ["A. suspense", "B. eloquence", "C. brevity", "D. ambiguity"],
        "answer" => "B"
    ]
];


$current_question = isset($_SESSION['current_question']) ? $_SESSION['current_question'] : 1;
$score = isset($_SESSION['score']) ? $_SESSION['score'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_option = $_POST['option'];
    if ($selected_option == $questions[$current_question]['answer']) {
        $score++;
        $_SESSION['score'] = $score;
    }
    $current_question++;
    $_SESSION['current_question'] = $current_question;
}

// Set the time limit in seconds (30 minutes = 30 * 60 seconds)
$time_limit = 30 * 60;
$end_time = isset($_SESSION['quiz_end_time']) ? $_SESSION['quiz_end_time'] : time() + $time_limit;
$_SESSION['quiz_end_time'] = $end_time;

// Calculate time left
$time_left = $end_time - time();
if ($time_left < 0) {
    $time_left = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quantitude Exercise</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 10px 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            display: block;
            margin: 20px 0;
            padding: 10px 15px;
            background-color: #5cb85c;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .score {
            font-size: 20px;
            color: #333;
        }
        #timer {
            font-size: 20px;
            margin-bottom: 20px;
            color: #ff0000;
        }
        .btn-container {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #0056b3;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .btn:hover {
            background-color: #004499;
        }
    </style>
    <script>
        // JavaScript countdown timer
        var timerInterval = setInterval(function() {
            var now = <?php echo time(); ?>;
            var endTime = <?php echo $_SESSION['quiz_end_time']; ?>;
            var timeLeft = endTime - now;

            var minutes = Math.floor(timeLeft / 60);
            var seconds = timeLeft % 60;

            document.getElementById('timer').textContent = 'Time left: ' + minutes + 'm ' + seconds + 's';

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timer').textContent = 'Time is up!';
                document.getElementById('quizForm').submit(); // Automatically submit the quiz when time is up
            }
        }, 1000);
    </script>
</head>
<body>
    <div class="container">
        <?php
        if ($current_question > count($questions)) {
            echo "<h1>Quiz Completed!</h1>";
            echo "<p>Your final score is: $score</p>";
            if ($score < 6){
                echo "<h5> To improve your score please refer to this study material: <a href='https://www.indiabix.com/verbal-ability/questions-and-answers/'>Click me</a></h5>  ";
                }
            echo "<div class='btn-container'>";
            echo "<a class='btn' href='verbal.php'>Retry</a>";
            echo "<a class='btn' href='/project/DropdownSection/index.php'>Go Back</a>";
            echo "</div>";
            session_destroy();
        } else {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                echo "<p class='score'>Your current score is: $score</p>";
            }
            $question = $questions[$current_question]['question'];
            $options = $questions[$current_question]['options'];
            echo "<h1>Question $current_question</h1>";
            echo "<p>$question</p>";
            echo "<form id='quizForm' method='POST'>";
            foreach ($options as $option) {
                echo "<p><input type='radio' name='option' value='" . substr($option, 0, 1) . "' required> $option</p>";
            }
            echo "<input type='submit' value='Submit'>";
            echo "</form>";
        }
        ?>
        <div id="timer"></div>
    </div>
</body>
</html>
