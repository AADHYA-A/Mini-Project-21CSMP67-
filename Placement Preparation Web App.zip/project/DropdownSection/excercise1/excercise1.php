<?php
session_start();

// Define the questions and options
$questions = [
    1 => [
        "question" => "What is the capital of France?",
        "options" => ["A. Paris", "B. London", "C. Rome", "D. Madrid"],
        "answer" => "A"
    ],
    2 => [
        "question" => "What is 5 + 3?",
        "options" => ["A. 6", "B. 7", "C. 8", "D. 9"],
        "answer" => "C"
    ],
    3 => [
        "question" => "Which is a synonym for 'happy'?",
        "options" => ["A. Sad", "B. Joyful", "C. Angry", "D. Tired"],
        "answer" => "B"
    ],
    4 => [
        "question" => "What is the largest planet in our solar system?",
        "options" => ["A. Earth", "B. Mars", "C. Jupiter", "D. Saturn"],
        "answer" => "C"
    ],
    5 => [
        "question" => "What is 7 * 6?",
        "options" => ["A. 42", "B. 36", "C. 48", "D. 54"],
        "answer" => "A"
    ]
];

$current_question = isset($_SESSION['current_question']) ? $_SESSION['current_question'] : 1;
$score = isset($_SESSION['score']) ? $_SESSION['score'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_option = $_POST['option'];
    if ($selected_option == $questions[$current_question]['answer']) {
        $score++;
        $_SESSION['score'] = $score;
    }
    $current_question++;
    $_SESSION['current_question'] = $current_question;
}

if ($current_question > count($questions)) {
    echo "<h1>Quiz Completed!</h1>";
    echo "<p>Your final score is: $score</p>";
    session_destroy();
} else {
    $question = $questions[$current_question]['question'];
    $options = $questions[$current_question]['options'];
    echo "<h1>Question $current_question</h1>";
    echo "<p>$question</p>";
    echo "<form method='POST'>";
    foreach ($options as $option) {
        echo "<input type='radio' name='option' value='" . $option[0] . "' required> $option<br>";
    }
    echo "<input type='submit' value='Submit'>";
    echo "</form>";
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        echo "<p>Your current score is: $score</p>";
    }
}
?>
