<?php
session_start();

// Define the questions and options
$questions = [
    1 => [
        "question" => "If x + y = 10 and x - y = 2, what is the value of x?",
        "options" => ["A. 4", "B. 6", "C. 8", "D. 5"],
        "answer" => "B"
    ],
    2 => [
        "question" => "A car travels at a speed of 60 miles per hour. How long will it take to travel 180 miles?",
        "options" => ["A. 2 hours", "B. 2.5 hours", "C. 3 hours", "D. 3.5 hours"],
        "answer" => "C"
    ],
    3 => [
        "question" => "If 3x - 2 = 7, what is the value of x?",
        "options" => ["A. 1", "B. 2", "C. 3", "D. 4"],
        "answer" => "D"
    ],
    4 => [
        "question" => "The average of five consecutive numbers is 15. What is the smallest number?",
        "options" => ["A. 13", "B. 14", "C. 15", "D. 16"],
        "answer" => "A"
    ],
    5 => [
        "question" => "What is the sum of the first 10 positive integers?",
        "options" => ["A. 45", "B. 50", "C. 55", "D. 60"],
        "answer" => "C"
    ]
];

$current_question = isset($_SESSION['current_question']) ? $_SESSION['current_question'] : 1;
$score = isset($_SESSION['score']) ? $_SESSION['score'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_option = $_POST['option'];
    if ($selected_option == $questions[$current_question]['answer']) {
        $score++;
        $_SESSION['score'] = $score;
    }
    $current_question++;
    $_SESSION['current_question'] = $current_question;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Quiz</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 10px 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            display: block;
            margin: 20px 0;
            padding: 10px 15px;
            background-color: #5cb85c;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .score {
            font-size: 20px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        if ($current_question > count($questions)) {
            echo "<h1>Quiz Completed!</h1>";
            echo "<p>Your final score is: $score</p>";
            session_destroy();
        } else {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                echo "<p class='score'>Your current score is: $score</p>";
            }
            $question = $questions[$current_question]['question'];
            $options = $questions[$current_question]['options'];
            echo "<h1>Question $current_question</h1>";
            echo "<p>$question</p>";
            echo "<form method='POST'>";
            foreach ($options as $option) {
                echo "<p><input type='radio' name='option' value='" . $option[0] . "' required> $option</p>";
            }
            echo "<input type='submit' value='Submit'>";
            echo "</form>";
        }
        ?>
    </div>
</body>
</html>
