<?php
session_start();

// Define the questions and options
$questions = [
    1 => [
        "question" => "If x + y = 10 and x - y = 2, what is the value of x?",
        "options" => ["A. 4", "B. 6", "C. 8", "D. 5"],
        "answer" => "B"
    ],
    2 => [
        "question" => "A car travels at a speed of 60 miles per hour. How long will it take to travel 180 miles?",
        "options" => ["A. 2 hours", "B. 2.5 hours", "C. 3 hours", "D. 3.5 hours"],
        "answer" => "C"
    ],
    3 => [
        "question" => "If 3x - 2 = 7, what is the value of x?",
        "options" => ["A. 1", "B. 2", "C. 3", "D. 4"],
        "answer" => "D"
    ],
    4 => [
        "question" => "The average of five consecutive numbers is 15. What is the smallest number?",
        "options" => ["A. 13", "B. 14", "C. 15", "D. 16"],
        "answer" => "A"
    ],
    5 => [
        "question" => "What is the sum of the first 10 positive integers?",
        "options" => ["A. 45", "B. 50", "C. 55", "D. 60"],
        "answer" => "C"
    ],
    6 => [
        "question" => "If a rectangle has a length of 10 and a width of 5, what is its area?",
        "options" => ["A. 50", "B. 30", "C. 20", "D. 10"],
        "answer" => "A"
    ],
    7 => [
        "question" => "What is the next number in the series: 2, 6, 12, 20, 30, ...?",
        "options" => ["A. 42", "B. 44", "C. 48", "D. 54"],
        "answer" => "A"
    ],
    8 => [
        "question" => "Solve for x: 2x + 3 = 11",
        "options" => ["A. 3", "B. 4", "C. 5", "D. 6"],
        "answer" => "B"
    ],
    9 => [
        "question" => "What is 15% of 200?",
        "options" => ["A. 25", "B. 30", "C. 35", "D. 40"],
        "answer" => "B"
    ],
    10 => [
        "question" => "What is the value of (5^2) - (3^2)?",
        "options" => ["A. 4", "B. 8", "C. 16", "D. 19"],
        "answer" => "C"
    ],
    11 => [
        "question" => "If x^2 = 49, what is x?",
        "options" => ["A. 5", "B. 6", "C. 7", "D. 8"],
        "answer" => "C"
    ],
    12 => [
        "question" => "The perimeter of a square is 16. What is the length of one side?",
        "options" => ["A. 2", "B. 3", "C. 4", "D. 5"],
        "answer" => "C"
    ],
    13 => [
        "question" => "What is the cube root of 27?",
        "options" => ["A. 2", "B. 3", "C. 4", "D. 5"],
        "answer" => "B"
    ],
    14 => [
        "question" => "If a train travels 240 miles in 4 hours, what is its average speed?",
        "options" => ["A. 50 mph", "B. 55 mph", "C. 60 mph", "D. 65 mph"],
        "answer" => "C"
    ],
    15 => [
        "question" => "What is the value of 7! (7 factorial)?",
        "options" => ["A. 5040", "B. 4030", "C. 3020", "D. 2010"],
        "answer" => "A"
    ],
    16 => [
        "question" => "What is the hypotenuse of a right triangle with legs of 3 and 4?",
        "options" => ["A. 5", "B. 6", "C. 7", "D. 8"],
        "answer" => "A"
    ],
    17 => [
        "question" => "If 4x = 20, what is x?",
        "options" => ["A. 3", "B. 4", "C. 5", "D. 6"],
        "answer" => "C"
    ],
    18 => [
        "question" => "What is the decimal equivalent of 1/8?",
        "options" => ["A. 0.125", "B. 0.250", "C. 0.375", "D. 0.500"],
        "answer" => "A"
    ],
    19 => [
        "question" => "What is the value of (2^4) * (2^3)?",
        "options" => ["A. 32", "B. 64", "C. 128", "D. 256"],
        "answer" => "A"
    ],
    20 => [
        "question" => "If x + 2y = 10 and y = 2, what is the value of x?",
        "options" => ["A. 2", "B. 4", "C. 6", "D. 8"],
        "answer" => "B"
    ]
];

$current_question = isset($_SESSION['current_question']) ? $_SESSION['current_question'] : 1;
$score = isset($_SESSION['score']) ? $_SESSION['score'] : 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $selected_option = $_POST['option'];
    if ($selected_option == $questions[$current_question]['answer']) {
        $score++;
        $_SESSION['score'] = $score;
    }
    $current_question++;
    $_SESSION['current_question'] = $current_question;
}

// Set the time limit in seconds (30 minutes = 30 * 60 seconds)
$time_limit = 30 * 60;
$end_time = isset($_SESSION['quiz_end_time']) ? $_SESSION['quiz_end_time'] : time() + $time_limit;
$_SESSION['quiz_end_time'] = $end_time;

// Calculate time left
$time_left = $end_time - time();
if ($time_left < 0) {
    $time_left = 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quantitude Exercise</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 10px 0;
        }
        form {
            margin-top: 20px;
        }
        input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            display: block;
            margin: 20px 0;
            padding: 10px 15px;
            background-color: #5cb85c;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        .score {
            font-size: 20px;
            color: #333;
        }
        #timer {
            font-size: 20px;
            margin-bottom: 20px;
            color: #ff0000;
        }
        .btn-container {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #0056b3;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-right: 10px;
        }
        .btn:hover {
            background-color: #004499;
        }
    </style>
    <script>
        // JavaScript countdown timer
        var timerInterval = setInterval(function() {
            var now = <?php echo time(); ?>;
            var endTime = <?php echo $_SESSION['quiz_end_time']; ?>;
            var timeLeft = endTime - now;

            var minutes = Math.floor(timeLeft / 60);
            var seconds = timeLeft % 60;

            document.getElementById('timer').textContent = 'Time left: ' + minutes + 'm ' + seconds + 's';

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timer').textContent = 'Time is up!';
                document.getElementById('quizForm').submit(); // Automatically submit the quiz when time is up
            }
        }, 1000);
    </script>
</head>
<body>
    <div class="container">
        <?php
        if ($current_question > count($questions)) {
            echo "<h1>Quiz Completed!</h1>";
            echo "<p>Your final score is: $score</p>";
            if ($score < 12){
                echo "<h5> To improve your score please refer to this study material: <a href='https://www.indiabix.com/aptitude/questions-and-answers/'>Click me</a></h5>  ";
                }
            echo "<div class='btn-container'>";
            echo "<a class='btn' href='quantitude.php'>Retry</a>";
            echo "<a class='btn' href='/project/DropdownSection/index.php'>Go Back</a>";
            echo "</div>";
            session_destroy();
        } else {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                echo "<p class='score'>Your current score is: $score</p>";
            }
            $question = $questions[$current_question]['question'];
            $options = $questions[$current_question]['options'];
            echo "<h1>Question $current_question</h1>";
            echo "<p>$question</p>";
            echo "<form id='quizForm' method='POST'>";
            foreach ($options as $option) {
                echo "<p><input type='radio' name='option' value='" . substr($option, 0, 1) . "' required> $option</p>";
            }
            echo "<input type='submit' value='Submit'>";
            echo "</form>";
        }
        ?>
        <div id="timer"></div>
    </div>
</body>
</html>
